package com.example.mongoblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
